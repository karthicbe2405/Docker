export class Notification {
	text: string;
	createdTime: string;
}
