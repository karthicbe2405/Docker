export class Task {
  title: string;
  description: string;
  reminderTime: string;
  createdBy?: number;
  assignedTo: number;
}
