export class AddTask {
	title: string;
	description: string;
	reminderTime: string;
	assignedTo: number;
}
